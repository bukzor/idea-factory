Neo4j System Libraries
=======================================

Nobody really knows what these things are for, but if anything
happens to them the server will be sad.


